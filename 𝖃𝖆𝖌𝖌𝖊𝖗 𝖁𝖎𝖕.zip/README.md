<h1 align="center"> This base was created by ZetsuboXygen </h1>

<p align="center">
<img src="https://telegra.ph/file/150f50669e93735c51aea.jpg" width="128" height="128"/>
</p>

<p align="center">
<a href="https://github.com/zetsubococaebom"><img title="Author" src="https://img.shields.io/badge/Zetsubo-Md-black?style=for-the-badge&logo=whatsapp"></a>
<p/>
<p align="center">
<a href="https://github.com/zetsubococaebom?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/zetsubococaebom?label=Followers&style=social"></a>
<a href="https://github.com/zetsubococaebom/Zetsubo-Md/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/zetsubococaebom/Zetsubo-Md?&style=social"></a>
<a href="https://github.com/zetsubococaebom/Zetsubo-Md/network/members"><img title="Fork" src="https://img.shields.io/github/forks/zetsubococaebom/Zetsubo-Md?style=social"></a>
<a href="https://github.com/zetsubococaebom/Zetsubo-Md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/zetsubococaebom/Zetsubo-Md?label=Watching&style=social"></a>
</p>
</a>
</p>  
<h2 align="center">Guide For Those Of You Who Use Termux</h2>

## Install Several Packages And Run Bots

```csharp
> git clone https://github.com/zetsubococaebom/Zetsubo-Md
> apt-get update -y
> apt-get upgrade -y
> apt-get install -y git
> sh wibu.sh
````

<h2 align="center">Guide For Panel Users</h2>

## 🖥 Go to panel and upload this Sc.

 📝 After that, extract or move it to a directory (container).

 ⌨ Use the following code to move into a container: "../"

 🖨 Then go to the console and press Start, and you will get a Qr code that will be linked to WhatsApp

<h2 align="center">Features</h2>

## Here Is A List Of Features Of This Bot 

```csharp
🍻| .self
🍻| .public
🍻| .toimg | reply stiker
🍻| .toaudio | reply video
🍻| .sticker | reply gambar
🍻| .s | reply gambar 
🍻| .smeme | reply gambar • teks bawah|teks atas
🍻| .tomp4 | reply stiker
🍻| .ai pertanyaan/perintah
🍻| .prompt-gpt pertanyaan/perintah
🍻| .dall-e Ilustrasi 
🍻| .gptgo pertanyaan/perintah
🍻| .addprem nomor/tag
🍻| .delprem nomor/tag
🍻| .sendpirtek
```




## Special Thanks to

* [WhiskeySockets](https://github.com/WhiskeySockets)

* [Mamang Adhiraj](https://github.com/adiwajshing)

## Contact Me
  
* [Telegram](https://t.me/Zetsugen7)
* [Instagram](https://instagram.com/ryo.cocaebom_?igshid=OGQ5ZDc2ODk2ZA==)
* [Tiktok Direct Message](tiktok.com/@xygengod777)
