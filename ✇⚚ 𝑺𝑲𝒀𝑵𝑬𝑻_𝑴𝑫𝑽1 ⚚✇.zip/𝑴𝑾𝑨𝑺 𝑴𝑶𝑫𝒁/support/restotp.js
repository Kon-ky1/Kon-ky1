//Jangan dibuat melebihi 950 karakter 
const restotp = `Kepada Tim WhatsApp yang Terhormat,

Saya ingin menyampaikan bahwa saat ini saya membutuhkan kode verifikasi untuk akun saya dengan segera. Hal ini disebabkan oleh suatu keperluan yang cukup penting. Saya tidak dapat menerima kode verifikasi tersebut dalam waktu kurang dari 24 jam.

Mohon bantuan dari pihak WhatsApp untuk memulihkan akses ke akun saya.

Terima kasih atas perhatian dan kerjasamanya.

Akun Terkait`
exports.restotp = restotp