//Jangan dibuat melebihi 950 karakter 
const unban3 = `Pihak WhatsApp,

Kami ingin menyampaikan keluhan mengenai penangguhan akun panti jompo kami yang kami anggap tidak adil Akun eksklusif kami untuk perawatan panti jompo dilarang tanpa alasan yang jelas Kami mohon agar masalah ini segera ditangani dengan serius dan mendapatkan respons yang memadai.

Akun ini sangat penting dalam memberikan pelayanan kesehatan berkualitas kepada pasien kami, dan penangguhan ini mengganggu operasional kami serta membahayakan kesejahteraan beberapa lansia yang kami layani.

Kami tidak dapat memulihkan akun kami karena telah diblokir secara permanen. Kami ingin mengklarifikasi bahwa kami tidak mengetahui kesalahan apa yang kami lakukan di WhatsApp hingga kami diblokir.

Kami meyakini bahwa tuduhan ini mungkin merupakan tindakan seseorang yang tidak senang atau iri terhadap kami. Oleh karena itu, kami meminta bantuan dari tim WhatsApp untuk memulihkan akun kami.

Informasi Akun Terkait kami ; `
exports.unban3 = unban3